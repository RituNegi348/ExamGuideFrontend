import { createContext, useState } from "react";

export const userContext = createContext();

export const UserContextProvider = ({ children }) => {
    const [user, setUser] = useState("ritu");
    const [data, setData] = useState([
        {
            course: "BBA",
            SEM1: ["C:\\Users\\ritun\\OneDrive\\Desktop\\exam_guide_frontend\\src\\Data\\BBA\\SAM.pdf",
                "C:\\Users\\ritun\\OneDrive\\Desktop\\exam_guide_frontend\\src\\Data\\BBA\\SAM1.pdf",
                "C:\\Users\\ritun\\OneDrive\\Desktop\\exam_guide_frontend\\src\\Data\\BBA\\SAM.pdf"],
        SEM2:  ["C:\\Users\\ritun\\OneDrive\\Desktop\\exam_guide_frontend\\src\\Data\\BBA\\SAM.pdf",
                "C:\\Users\\ritun\\OneDrive\\Desktop\\exam_guide_frontend\\src\\Data\\BBA\\SAM.pdf",
                "C:\\Users\\ritun\\OneDrive\\Desktop\\exam_guide_frontend\\src\\Data\\BBA\\SAM.pdf"],
        },{
            course: "BCA",
            SEM1: ["C:\\Users\\ritun\\OneDrive\\Desktop\\exam_guide_frontend\\src\\Data\\BBA\\SAM.pdf",
                "C:\\Users\\ritun\\OneDrive\\Desktop\\exam_guide_frontend\\src\\Data\\BBA\\SAM1.pdf",
                "C:\\Users\\ritun\\OneDrive\\Desktop\\exam_guide_frontend\\src\\Data\\BBA\\SAM.pdf"],

            SEM2: ["C:\\Users\\ritun\\OneDrive\\Desktop\\exam_guide_frontend\\src\\Data\\BBA\\SAM.pdf",
                "C:\\Users\\ritun\\OneDrive\\Desktop\\exam_guide_frontend\\src\\Data\\BBA\\SAM1.pdf",
                "C:\\Users\\ritun\\OneDrive\\Desktop\\exam_guide_frontend\\src\\Data\\BBA\\SAM.pdf"],
        },{
            course: "MCA",

            SEM1:  ["C:\\Users\\ritun\\OneDrive\\Desktop\\exam_guide_frontend\\src\\Data\\BBA\\SAM.pdf",
                "C:\\Users\\ritun\\OneDrive\\Desktop\\exam_guide_frontend\\src\\Data\\BBA\\SAM.pdf",
                "C:\\Users\\ritun\\OneDrive\\Desktop\\exam_guide_frontend\\src\\Data\\BBA\\SAM.pdf"],

            SEM2:  ["C:\\Users\\ritun\\OneDrive\\Desktop\\exam_guide_frontend\\src\\Data\\BBA\\SAM.pdf",
                "C:\\Users\\ritun\\OneDrive\\Desktop\\exam_guide_frontend\\src\\Data\\BBA\\SAM.pdf",
                "C:\\Users\\ritun\\OneDrive\\Desktop\\exam_guide_frontend\\src\\Data\\BBA\\SAM.pdf"],

        },{course: "MBA",
            SEM1:
                ["C:\\Users\\ritun\\OneDrive\\Desktop\\exam_guide_frontend\\src\\Data\\BBA\\SAM.pdf",
                "C:\\Users\\ritun\\OneDrive\\Desktop\\exam_guide_frontend\\src\\Data\\BBA\\SAM.pdf",
                "C:\\Users\\ritun\\OneDrive\\Desktop\\exam_guide_frontend\\src\\Data\\BBA\\SAM.pdf"],
            SEM2:
            ["C:\\Users\\ritun\\OneDrive\\Desktop\\exam_guide_frontend\\src\\Data\\BBA\\SAM.pdf",
                "C:\\Users\\ritun\\OneDrive\\Desktop\\exam_guide_frontend\\src\\Data\\BBA\\SAM.pdf",
                "C:\\Users\\ritun\\OneDrive\\Desktop\\exam_guide_frontend\\src\\Data\\BBA\\SAM.pdf"],
            }
    ]);
    const [selected, setSelected] = useState(null);
    const [selectedSem, setSelectedSem] = useState(null);
    return <userContext.Provider value={{ user, setUser, selected, setSelected, selectedSem, setSelectedSem, data, setData }}>{children}</userContext.Provider>
}
