import React from 'react';
import Header from '../Components/Header';
import LeftSideBar from '../Components/LeftSideBar';
import CourseContent from '../Components/CourseContent';

const MainPage = () => {
  // You can replace this with actual username from your auth system
  const username = "John Doe";

  return (
    <div className="min-h-screen bg-gray-50">
      <Header username={username} />
      <div className="flex">
        <LeftSideBar />
        <main className="flex-1 p-6">
          <CourseContent />
        </main>
      </div>
    </div>
  );
};

export default MainPage;
