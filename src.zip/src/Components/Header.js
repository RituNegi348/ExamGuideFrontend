import React, { useState, useContext } from 'react';
import { Avatar, Menu, MenuItem } from '@mui/material';
import { userContext } from '../Context/userContext';

const Header = ({ username }) => {
  const {user} = useContext(userContext);
  const [anchorEl, setAnchorEl] = useState(null);
  const open = Boolean(anchorEl);

  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  const handleUpload = () => {
    // Handle upload functionality
    handleClose();
  };

  const handleLogout = () => {
    // Handle logout functionality
    handleClose();
  };

  return (
    <header className="bg-white shadow-md px-6 py-4">
      <div className="max-w-7xl mx-auto flex justify-between items-center">
        <h1 className="text-2xl font-bold text-blue-600">Exam Guide</h1>
        
        <div className="flex items-center">
          <span className="mr-4 text-gray-700">{user}</span>
          <Avatar
            onClick={handleClick}
            className="cursor-pointer hover:opacity-80"
          />
          
          <Menu
            anchorEl={anchorEl}
            open={open}
            onClose={handleClose}
            MenuListProps={{
              'aria-labelledby': 'basic-button',
            }}
          >
            <MenuItem onClick={handleUpload}>Upload</MenuItem>
            <MenuItem onClick={handleLogout}>Logout</MenuItem>
          </Menu>
        </div>
      </div>
    </header>
  );
};

export default Header;