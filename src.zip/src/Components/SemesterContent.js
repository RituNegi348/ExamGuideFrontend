import React, { useContext } from 'react';
import { ArrowBack, PictureAsPdf } from '@mui/icons-material';
import { userContext } from '../Context/userContext';

const SemesterContent = () => {
  const { selected, data, selectedSem, setSelectedSem } = useContext(userContext);
  
  const selectedCourse = data.find(course => course.course === selected);
  const semesterData = selectedCourse[selectedSem];

  const handleDownload = (pdfPath) => {
    const fileName = pdfPath.split('\\').pop();
    
    const link = document.createElement('a');
    link.href = pdfPath;
    link.download = fileName;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const getFileNameFromPath = (path) => {
    // Get everything after the last slash and before .pdf
    const paths = path.split('\\');
    const fileName = paths[paths.length - 1].split('.')[0];
    console.log(fileName);
    return fileName;
  };

  return (
    <div className="p-6">
      <div className="flex items-center mb-6">
        <button
          onClick={() => setSelectedSem(null)}
          className="flex items-center text-blue-600 hover:text-blue-700 transition-colors"
        >
          <ArrowBack className="mr-2" />
          <span>Back to Course</span>
        </button>
      </div>

      <h2 className="text-2xl font-semibold text-gray-800 mb-6">
        {selected} - {selectedSem}
      </h2>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {Array.isArray(semesterData) && semesterData.map((pdfPath, index) => (
          <div
            key={index}
            onClick={() => handleDownload(pdfPath)}
            className="bg-white p-4 rounded-lg shadow-md hover:shadow-lg transition-all cursor-pointer"
          >
            <div className="flex items-center space-x-3">
              <PictureAsPdf className="text-red-500" />
              <h3 className="text-lg font-medium text-gray-700">
                {getFileNameFromPath(pdfPath)}
              </h3>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default SemesterContent; 